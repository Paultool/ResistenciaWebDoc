import React, { useState, useEffect } from 'react'
import { supabase, obtenerPersonajes, Personaje } from '../supabaseClient'

const AdminPersonajes: React.FC = () => {
  const [personajes, setPersonajes] = useState<Personaje[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [showCreateForm, setShowCreateForm] = useState(false)
  const [editingPersonaje, setEditingPersonaje] = useState<Personaje | null>(null)
  const [formData, setFormData] = useState({
    nombre: '',
    descripcion: '',
    imagen: '',
    atributos_json: '{}'
  })

  useEffect(() => {
    cargarPersonajes()
  }, [])

  const cargarPersonajes = async () => {
    try {
      setLoading(true)
      const personajesData = await obtenerPersonajes()
      setPersonajes(personajesData)
    } catch (err: any) {
      setError('Error cargando personajes: ' + err.message)
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    try {
      // Validar JSON
      JSON.parse(formData.atributos_json)
      
      if (editingPersonaje) {
        const { error } = await supabase
          .from('personaje')
          .update({
            nombre: formData.nombre,
            descripcion: formData.descripcion,
            imagen: formData.imagen,
            atributos_json: formData.atributos_json
          })
          .eq('id_personaje', editingPersonaje.id)
        
        if (error) throw error
        alert('✅ Personaje actualizado exitosamente')
      } else {
        const { error } = await supabase
          .from('personaje')
          .insert({
            nombre: formData.nombre,
            descripcion: formData.descripcion,
            imagen: formData.imagen,
            atributos_json: formData.atributos_json
          })
        
        if (error) throw error
        alert('✅ Personaje creado exitosamente')
      }
      
      resetForm()
      cargarPersonajes()
    } catch (error: any) {
      alert('❌ Error: ' + error.message)
    }
  }

  const handleEdit = (personaje: Personaje) => {
    setEditingPersonaje(personaje)
    setFormData({
      nombre: personaje.nombre,
      descripcion: personaje.descripcion,
      imagen: personaje.imagen || '',
      atributos_json: JSON.stringify(personaje.metadata || {}, null, 2)
    })
    setShowCreateForm(true)
  }

  const handleDelete = async (personaje: Personaje) => {
    if (!confirm(`¿Estás seguro de eliminar el personaje "${personaje.nombre}"?`)) {
      return
    }
    
    try {
      const { error } = await supabase
        .from('personaje')
        .delete()
        .eq('id_personaje', personaje.id)
      
      if (error) throw error
      
      alert('✅ Personaje eliminado exitosamente')
      cargarPersonajes()
    } catch (error: any) {
      alert('❌ Error eliminando personaje: ' + error.message)
    }
  }

  const resetForm = () => {
    setFormData({
      nombre: '',
      descripcion: '',
      imagen: '',
      atributos_json: '{}'
    })
    setEditingPersonaje(null)
    setShowCreateForm(false)
  }

  return (
    <div className="admin-personajes">
      <div className="admin-content-header">
        <h2>🎭 Gestión de Personajes</h2>
        <button 
          className="btn btn-primary"
          onClick={() => setShowCreateForm(true)}
        >
          ➕ Nuevo Personaje
        </button>
      </div>

      {showCreateForm && (
        <div className="modal-overlay">
          <div className="modal">
            <div className="modal-header">
              <h3>{editingPersonaje ? '✏️ Editar Personaje' : '🆕 Nuevo Personaje'}</h3>
              <button onClick={resetForm} className="btn-close">×</button>
            </div>
            
            <form onSubmit={handleSubmit} className="personaje-form">
              <div className="form-group">
                <label>Nombre:</label>
                <input
                  type="text"
                  value={formData.nombre}
                  onChange={(e) => setFormData({...formData, nombre: e.target.value})}
                  required
                />
              </div>
              
              <div className="form-group">
                <label>Descripción:</label>
                <textarea
                  value={formData.descripcion}
                  onChange={(e) => setFormData({...formData, descripcion: e.target.value})}
                  required
                  rows={3}
                />
              </div>
              
              <div className="form-group">
                <label>URL de Imagen:</label>
                <input
                  type="url"
                  value={formData.imagen}
                  onChange={(e) => setFormData({...formData, imagen: e.target.value})}
                  placeholder="https://ejemplo.com/imagen.jpg"
                />
              </div>
              
              <div className="form-group">
                <label>Atributos (JSON):</label>
                <textarea
                  value={formData.atributos_json}
                  onChange={(e) => setFormData({...formData, atributos_json: e.target.value})}
                  rows={4}
                  placeholder='{"profesion": "Activista", "edad": 35, "ubicacion": "Tepito"}'
                />
              </div>
              
              <div className="form-actions">
                <button type="submit" className="btn btn-success">
                  {editingPersonaje ? '💾 Actualizar' : '➕ Crear'}
                </button>
                <button type="button" onClick={resetForm} className="btn btn-secondary">
                  ❌ Cancelar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="admin-table-container">
        {loading ? (
          <div className="loading">⏳ Cargando personajes...</div>
        ) : error ? (
          <div className="error">❌ {error}</div>
        ) : (
          <table className="admin-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Imagen</th>
                <th>Nombre</th>
                <th>Rol</th>
                <th>Descripción</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {personajes.map((personaje) => (
                <tr key={personaje.id}>
                  <td>#{personaje.id}</td>
                  <td>
                    {personaje.imagen ? (
                      <img src={personaje.imagen} alt={personaje.nombre} className="thumbnail" />
                    ) : (
                      <div className="no-image">📷</div>
                    )}
                  </td>
                  <td><strong>{personaje.nombre}</strong></td>
                  <td>{personaje.rol}</td>
                  <td>
                    <div className="description-preview">
                      {personaje.descripcion?.substring(0, 80)}...
                    </div>
                  </td>
                  <td className="actions">
                    <button 
                      onClick={() => handleEdit(personaje)}
                      className="btn btn-sm btn-info"
                      title="Editar"
                    >
                      ✏️
                    </button>
                    <button 
                      onClick={() => handleDelete(personaje)}
                      className="btn btn-sm btn-danger"
                      title="Eliminar"
                    >
                      🗑️
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
      
      <div className="admin-summary">
        <p>📊 Total de personajes: <strong>{personajes.length}</strong></p>
      </div>
    </div>
  )
}

export default AdminPersonajes