import React, { useState, useEffect } from 'react'
import { supabase, obtenerUbicaciones, Ubicacion } from '../supabaseClient'

const AdminUbicaciones: React.FC = () => {
  const [ubicaciones, setUbicaciones] = useState<Ubicacion[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [showCreateForm, setShowCreateForm] = useState(false)
  const [editingUbicacion, setEditingUbicacion] = useState<Ubicacion | null>(null)
  const [formData, setFormData] = useState({
    nombre: '',
    descripcion: '',
    coordenadas: '',
    tipo: 'plaza'
  })

  useEffect(() => {
    cargarUbicaciones()
  }, [])

  const cargarUbicaciones = async () => {
    try {
      setLoading(true)
      const ubicacionesData = await obtenerUbicaciones()
      setUbicaciones(ubicacionesData)
    } catch (err: any) {
      setError('Error cargando ubicaciones: ' + err.message)
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    try {
      // Validar formato de coordenadas
      const coords = formData.coordenadas.split(',').map(c => parseFloat(c.trim()))
      if (coords.length !== 2 || coords.some(isNaN)) {
        throw new Error('Las coordenadas deben tener formato: latitud, longitud')
      }
      
      if (editingUbicacion) {
        const { error } = await supabase
          .from('ubicacion')
          .update({
            nombre: formData.nombre,
            descripcion: formData.descripcion,
            coordenadas: formData.coordenadas,
            tipo: formData.tipo
          })
          .eq('id_ubicacion', editingUbicacion.id)
        
        if (error) throw error
        alert('✅ Ubicación actualizada exitosamente')
      } else {
        const { error } = await supabase
          .from('ubicacion')
          .insert({
            nombre: formData.nombre,
            descripcion: formData.descripcion,
            coordenadas: formData.coordenadas,
            tipo: formData.tipo
          })
        
        if (error) throw error
        alert('✅ Ubicación creada exitosamente')
      }
      
      resetForm()
      cargarUbicaciones()
    } catch (error: any) {
      alert('❌ Error: ' + error.message)
    }
  }

  const handleEdit = (ubicacion: Ubicacion) => {
    setEditingUbicacion(ubicacion)
    setFormData({
      nombre: ubicacion.nombre,
      descripcion: ubicacion.descripcion,
      coordenadas: `${ubicacion.latitud}, ${ubicacion.longitud}`,
      tipo: ubicacion.metadata?.tipo || 'plaza'
    })
    setShowCreateForm(true)
  }

  const handleDelete = async (ubicacion: Ubicacion) => {
    if (!confirm(`¿Estás seguro de eliminar la ubicación "${ubicacion.nombre}"?`)) {
      return
    }
    
    try {
      const { error } = await supabase
        .from('ubicacion')
        .delete()
        .eq('id_ubicacion', ubicacion.id)
      
      if (error) throw error
      
      alert('✅ Ubicación eliminada exitosamente')
      cargarUbicaciones()
    } catch (error: any) {
      alert('❌ Error eliminando ubicación: ' + error.message)
    }
  }

  const resetForm = () => {
    setFormData({
      nombre: '',
      descripcion: '',
      coordenadas: '',
      tipo: 'plaza'
    })
    setEditingUbicacion(null)
    setShowCreateForm(false)
  }

  const openInGoogleMaps = (ubicacion: Ubicacion) => {
    const url = `https://www.google.com/maps/search/?api=1&query=${ubicacion.latitud},${ubicacion.longitud}`
    window.open(url, '_blank')
  }

  return (
    <div className="admin-ubicaciones">
      <div className="admin-content-header">
        <h2>🗺️ Gestión de Ubicaciones</h2>
        <button 
          className="btn btn-primary"
          onClick={() => setShowCreateForm(true)}
        >
          ➕ Nueva Ubicación
        </button>
      </div>

      {showCreateForm && (
        <div className="modal-overlay">
          <div className="modal">
            <div className="modal-header">
              <h3>{editingUbicacion ? '✏️ Editar Ubicación' : '🆕 Nueva Ubicación'}</h3>
              <button onClick={resetForm} className="btn-close">×</button>
            </div>
            
            <form onSubmit={handleSubmit} className="ubicacion-form">
              <div className="form-group">
                <label>Nombre:</label>
                <input
                  type="text"
                  value={formData.nombre}
                  onChange={(e) => setFormData({...formData, nombre: e.target.value})}
                  required
                />
              </div>
              
              <div className="form-group">
                <label>Descripción:</label>
                <textarea
                  value={formData.descripcion}
                  onChange={(e) => setFormData({...formData, descripcion: e.target.value})}
                  required
                  rows={3}
                />
              </div>
              
              <div className="form-row">
                <div className="form-group">
                  <label>Coordenadas (lat, lng):</label>
                  <input
                    type="text"
                    value={formData.coordenadas}
                    onChange={(e) => setFormData({...formData, coordenadas: e.target.value})}
                    placeholder="19.4326, -99.1332"
                    required
                  />
                </div>
                
                <div className="form-group">
                  <label>Tipo:</label>
                  <select
                    value={formData.tipo}
                    onChange={(e) => setFormData({...formData, tipo: e.target.value})}
                  >
                    <option value="plaza">Plaza</option>
                    <option value="mercado">Mercado</option>
                    <option value="barrio">Barrio</option>
                    <option value="centro">Centro</option>
                    <option value="parque">Parque</option>
                    <option value="cultural">Cultural</option>
                    <option value="historico">Histórico</option>
                    <option value="comunidad">Comunidad</option>
                    <option value="resistencia">Resistencia</option>
                  </select>
                </div>
              </div>
              
              <div className="form-actions">
                <button type="submit" className="btn btn-success">
                  {editingUbicacion ? '💾 Actualizar' : '➕ Crear'}
                </button>
                <button type="button" onClick={resetForm} className="btn btn-secondary">
                  ❌ Cancelar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="admin-table-container">
        {loading ? (
          <div className="loading">⏳ Cargando ubicaciones...</div>
        ) : error ? (
          <div className="error">❌ {error}</div>
        ) : (
          <table className="admin-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Tipo</th>
                <th>Coordenadas</th>
                <th>Descripción</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {ubicaciones.map((ubicacion) => (
                <tr key={ubicacion.id}>
                  <td>#{ubicacion.id}</td>
                  <td><strong>{ubicacion.nombre}</strong></td>
                  <td>
                    <span className={`type-badge ${ubicacion.metadata?.tipo || 'default'}`}>
                      {ubicacion.metadata?.tipo || 'N/A'}
                    </span>
                  </td>
                  <td>
                    <div className="coordinates">
                      <small>{ubicacion.latitud.toFixed(4)}, {ubicacion.longitud.toFixed(4)}</small>
                      <button 
                        onClick={() => openInGoogleMaps(ubicacion)}
                        className="btn btn-xs btn-link"
                        title="Ver en Google Maps"
                      >
                        🗺️
                      </button>
                    </div>
                  </td>
                  <td>
                    <div className="description-preview">
                      {ubicacion.descripcion?.substring(0, 60)}...
                    </div>
                  </td>
                  <td className="actions">
                    <button 
                      onClick={() => handleEdit(ubicacion)}
                      className="btn btn-sm btn-info"
                      title="Editar"
                    >
                      ✏️
                    </button>
                    <button 
                      onClick={() => handleDelete(ubicacion)}
                      className="btn btn-sm btn-danger"
                      title="Eliminar"
                    >
                      🗑️
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
      
      <div className="admin-summary">
        <p>📊 Total de ubicaciones: <strong>{ubicaciones.length}</strong></p>
        <p>📍 Tipos disponibles: Plaza, Mercado, Barrio, Centro, Parque, Cultural, Histórico, Comunidad, Resistencia</p>
      </div>
    </div>
  )
}

export default AdminUbicaciones