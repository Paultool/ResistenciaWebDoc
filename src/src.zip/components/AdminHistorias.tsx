import React, { useState, useEffect } from 'react'
import { supabase, obtenerHistorias, Historia } from '../supabaseClient'

const AdminHistorias: React.FC = () => {
  const [historias, setHistorias] = useState<Historia[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [showCreateForm, setShowCreateForm] = useState(false)
  const [editingHistoria, setEditingHistoria] = useState<Historia | null>(null)
  const [formData, setFormData] = useState({
    titulo: '',
    narrativa: '',
    estado: 'activa',
    orden: 1,
    id_ubicacion: 1
  })

  useEffect(() => {
    cargarHistorias()
  }, [])

  const cargarHistorias = async () => {
    try {
      setLoading(true)
      const historiasData = await obtenerHistorias()
      setHistorias(historiasData)
    } catch (err: any) {
      setError('Error cargando historias: ' + err.message)
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    try {
      if (editingHistoria) {
        // Actualizar historia existente
        const { error } = await supabase
          .from('historia')
          .update({
            titulo: formData.titulo,
            narrativa: formData.narrativa,
            estado: formData.estado,
            orden: formData.orden,
            id_ubicacion: formData.id_ubicacion
          })
          .eq('id_historia', editingHistoria.id)
        
        if (error) throw error
        alert('✅ Historia actualizada exitosamente')
      } else {
        // Crear nueva historia
        const { error } = await supabase
          .from('historia')
          .insert({
            titulo: formData.titulo,
            narrativa: formData.narrativa,
            estado: formData.estado,
            orden: formData.orden,
            id_ubicacion: formData.id_ubicacion
          })
        
        if (error) throw error
        alert('✅ Historia creada exitosamente')
      }
      
      resetForm()
      cargarHistorias()
    } catch (error: any) {
      alert('❌ Error: ' + error.message)
    }
  }

  const handleEdit = (historia: Historia) => {
    setEditingHistoria(historia)
    setFormData({
      titulo: historia.titulo,
      narrativa: historia.descripcion,
      estado: historia.metadata?.estado || 'activa',
      orden: historia.metadata?.ubicacion_id || 1,
      id_ubicacion: historia.metadata?.ubicacion_id || 1
    })
    setShowCreateForm(true)
  }

  const handleDelete = async (historia: Historia) => {
    if (!confirm(`¿Estás seguro de eliminar la historia "${historia.titulo}"?`)) {
      return
    }
    
    try {
      const { error } = await supabase
        .from('historia')
        .delete()
        .eq('id_historia', historia.id)
      
      if (error) throw error
      
      alert('✅ Historia eliminada exitosamente')
      cargarHistorias()
    } catch (error: any) {
      alert('❌ Error eliminando historia: ' + error.message)
    }
  }

  const resetForm = () => {
    setFormData({
      titulo: '',
      narrativa: '',
      estado: 'activa',
      orden: 1,
      id_ubicacion: 1
    })
    setEditingHistoria(null)
    setShowCreateForm(false)
  }

  return (
    <div className="admin-historias">
      <div className="admin-content-header">
        <h2>📚 Gestión de Historias</h2>
        <button 
          className="btn btn-primary"
          onClick={() => setShowCreateForm(true)}
        >
          ➕ Nueva Historia
        </button>
      </div>

      {showCreateForm && (
        <div className="modal-overlay">
          <div className="modal">
            <div className="modal-header">
              <h3>{editingHistoria ? '✏️ Editar Historia' : '🆕 Nueva Historia'}</h3>
              <button onClick={resetForm} className="btn-close">×</button>
            </div>
            
            <form onSubmit={handleSubmit} className="historia-form">
              <div className="form-group">
                <label>Título:</label>
                <input
                  type="text"
                  value={formData.titulo}
                  onChange={(e) => setFormData({...formData, titulo: e.target.value})}
                  required
                />
              </div>
              
              <div className="form-group">
                <label>Narrativa:</label>
                <textarea
                  value={formData.narrativa}
                  onChange={(e) => setFormData({...formData, narrativa: e.target.value})}
                  required
                  rows={4}
                />
              </div>
              
              <div className="form-row">
                <div className="form-group">
                  <label>Estado:</label>
                  <select
                    value={formData.estado}
                    onChange={(e) => setFormData({...formData, estado: e.target.value})}
                  >
                    <option value="activa">Activa</option>
                    <option value="borrador">Borrador</option>
                    <option value="archivada">Archivada</option>
                  </select>
                </div>
                
                <div className="form-group">
                  <label>Orden:</label>
                  <input
                    type="number"
                    value={formData.orden}
                    onChange={(e) => setFormData({...formData, orden: parseInt(e.target.value)})}
                    min="1"
                  />
                </div>
                
                <div className="form-group">
                  <label>ID Ubicación:</label>
                  <input
                    type="number"
                    value={formData.id_ubicacion}
                    onChange={(e) => setFormData({...formData, id_ubicacion: parseInt(e.target.value)})}
                    min="1"
                  />
                </div>
              </div>
              
              <div className="form-actions">
                <button type="submit" className="btn btn-success">
                  {editingHistoria ? '💾 Actualizar' : '➕ Crear'}
                </button>
                <button type="button" onClick={resetForm} className="btn btn-secondary">
                  ❌ Cancelar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="admin-table-container">
        {loading ? (
          <div className="loading">⏳ Cargando historias...</div>
        ) : error ? (
          <div className="error">❌ {error}</div>
        ) : (
          <table className="admin-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Título</th>
                <th>Estado</th>
                <th>Orden</th>
                <th>Tipo</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {historias.map((historia) => (
                <tr key={historia.id}>
                  <td>#{historia.id}</td>
                  <td>
                    <div className="historia-title">
                      <strong>{historia.titulo}</strong>
                      <small>{historia.descripcion?.substring(0, 50)}...</small>
                    </div>
                  </td>
                  <td>
                    <span className={`status-badge ${historia.metadata?.estado || 'activa'}`}>
                      {historia.metadata?.estado || 'activa'}
                    </span>
                  </td>
                  <td>{historia.metadata?.ubicacion_id}</td>
                  <td>
                    <span className={`type-badge ${historia.es_historia_principal ? 'principal' : 'secundaria'}`}>
                      {historia.es_historia_principal ? '⭐ Principal' : '📝 Secundaria'}
                    </span>
                  </td>
                  <td className="actions">
                    <button 
                      onClick={() => handleEdit(historia)}
                      className="btn btn-sm btn-info"
                      title="Editar"
                    >
                      ✏️
                    </button>
                    <button 
                      onClick={() => handleDelete(historia)}
                      className="btn btn-sm btn-danger"
                      title="Eliminar"
                    >
                      🗑️
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
      
      <div className="admin-summary">
        <p>📊 Total de historias: <strong>{historias.length}</strong></p>
        <p>⭐ Principales: <strong>{historias.filter(h => h.es_historia_principal).length}</strong></p>
        <p>📝 Secundarias: <strong>{historias.filter(h => !h.es_historia_principal).length}</strong></p>
      </div>
    </div>
  )
}

export default AdminHistorias