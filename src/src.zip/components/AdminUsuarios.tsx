import React, { useState, useEffect } from 'react'
import { supabase } from '../supabaseClient'
import { useAdmin } from '../hooks/useAdmin'

interface UsuarioData {
  id_usuario: number
  nombre: string
  email: string
  nivel: number
  rol: string
  fecha_registro: string
}

const AdminUsuarios: React.FC = () => {
  const { promoteToAdmin, revokeAdmin } = useAdmin()
  const [usuarios, setUsuarios] = useState<UsuarioData[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [showCreateForm, setShowCreateForm] = useState(false)
  const [formData, setFormData] = useState({
    nombre: '',
    email: '',
    rol: 'usuario'
  })

  useEffect(() => {
    cargarUsuarios()
  }, [])

  const cargarUsuarios = async () => {
    try {
      setLoading(true)
      const { data: usuariosData, error } = await supabase
        .from('usuario')
        .select('*')
        .order('fecha_registro', { ascending: false })
      
      if (error) throw error
      setUsuarios(usuariosData || [])
    } catch (err: any) {
      setError('Error cargando usuarios: ' + err.message)
    } finally {
      setLoading(false)
    }
  }

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault()
    
    try {
      const { error } = await supabase
        .from('usuario')
        .insert({
          nombre: formData.nombre,
          email: formData.email,
          nivel: 1,
          rol: formData.rol
        })
      
      if (error) throw error
      
      alert('✅ Usuario creado exitosamente')
      resetForm()
      cargarUsuarios()
    } catch (error: any) {
      alert('❌ Error: ' + error.message)
    }
  }

  const handlePromoteUser = async (usuario: UsuarioData) => {
    try {
      await promoteToAdmin(usuario.email)
      alert(`✅ ${usuario.nombre} ha sido promovido a administrador`)
      cargarUsuarios()
    } catch (error: any) {
      alert('❌ Error: ' + error.message)
    }
  }

  const handleRevokeAdmin = async (usuario: UsuarioData) => {
    if (!confirm(`¿Estás seguro de revocar permisos de admin a ${usuario.nombre}?`)) {
      return
    }
    
    try {
      await revokeAdmin(usuario.email)
      alert(`✅ Permisos de admin revocados para ${usuario.nombre}`)
      cargarUsuarios()
    } catch (error: any) {
      alert('❌ Error: ' + error.message)
    }
  }

  const handleDeleteUser = async (usuario: UsuarioData) => {
    if (!confirm(`¿Estás seguro de eliminar al usuario "${usuario.nombre}"?`)) {
      return
    }
    
    try {
      const { error } = await supabase
        .from('usuario')
        .delete()
        .eq('id_usuario', usuario.id_usuario)
      
      if (error) throw error
      
      alert('✅ Usuario eliminado exitosamente')
      cargarUsuarios()
    } catch (error: any) {
      alert('❌ Error eliminando usuario: ' + error.message)
    }
  }

  const resetForm = () => {
    setFormData({
      nombre: '',
      email: '',
      rol: 'usuario'
    })
    setShowCreateForm(false)
  }

  return (
    <div className="admin-usuarios">
      <div className="admin-content-header">
        <h2>👥 Gestión de Usuarios</h2>
        <button 
          className="btn btn-primary"
          onClick={() => setShowCreateForm(true)}
        >
          ➕ Nuevo Usuario
        </button>
      </div>

      {showCreateForm && (
        <div className="modal-overlay">
          <div className="modal">
            <div className="modal-header">
              <h3>🆕 Nuevo Usuario</h3>
              <button onClick={resetForm} className="btn-close">×</button>
            </div>
            
            <form onSubmit={handleCreateUser} className="usuario-form">
              <div className="form-group">
                <label>Nombre:</label>
                <input
                  type="text"
                  value={formData.nombre}
                  onChange={(e) => setFormData({...formData, nombre: e.target.value})}
                  required
                />
              </div>
              
              <div className="form-group">
                <label>Email:</label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  required
                />
              </div>
              
              <div className="form-group">
                <label>Rol:</label>
                <select
                  value={formData.rol}
                  onChange={(e) => setFormData({...formData, rol: e.target.value})}
                >
                  <option value="usuario">Usuario</option>
                  <option value="admin">Administrador</option>
                </select>
              </div>
              
              <div className="form-actions">
                <button type="submit" className="btn btn-success">
                  ➕ Crear Usuario
                </button>
                <button type="button" onClick={resetForm} className="btn btn-secondary">
                  ❌ Cancelar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="admin-table-container">
        {loading ? (
          <div className="loading">⏳ Cargando usuarios...</div>
        ) : error ? (
          <div className="error">❌ {error}</div>
        ) : (
          <table className="admin-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Email</th>
                <th>Nivel</th>
                <th>Rol</th>
                <th>Registro</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {usuarios.map((usuario) => (
                <tr key={usuario.id_usuario}>
                  <td>#{usuario.id_usuario}</td>
                  <td><strong>{usuario.nombre}</strong></td>
                  <td>{usuario.email}</td>
                  <td>{usuario.nivel}</td>
                  <td>
                    <span className={`role-badge ${usuario.rol}`}>
                      {usuario.rol === 'admin' ? '⚡ Admin' : '👤 Usuario'}
                    </span>
                  </td>
                  <td>
                    <small>{new Date(usuario.fecha_registro).toLocaleDateString('es-MX')}</small>
                  </td>
                  <td className="actions">
                    {usuario.rol !== 'admin' ? (
                      <button 
                        onClick={() => handlePromoteUser(usuario)}
                        className="btn btn-sm btn-warning"
                        title="Promover a Admin"
                      >
                        ⬆️
                      </button>
                    ) : (
                      <button 
                        onClick={() => handleRevokeAdmin(usuario)}
                        className="btn btn-sm btn-warning"
                        title="Revocar Admin"
                      >
                        ⬇️
                      </button>
                    )}
                    <button 
                      onClick={() => handleDeleteUser(usuario)}
                      className="btn btn-sm btn-danger"
                      title="Eliminar"
                    >
                      🗑️
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
      
      <div className="admin-summary">
        <p>📊 Total de usuarios: <strong>{usuarios.length}</strong></p>
        <p>⚡ Administradores: <strong>{usuarios.filter(u => u.rol === 'admin').length}</strong></p>
        <p>👤 Usuarios regulares: <strong>{usuarios.filter(u => u.rol === 'usuario').length}</strong></p>
      </div>
    </div>
  )
}

export default AdminUsuarios