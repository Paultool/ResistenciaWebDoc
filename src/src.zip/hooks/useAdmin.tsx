import { useState, useEffect } from 'react'
import { useAuth } from '../contexts/AuthContext'
import { supabase } from '../supabaseClient'

export interface AdminUser {
  id: string
  email: string
  isAdmin: boolean
  role: string
  metadata?: any
}

export const useAdmin = () => {
  const { user } = useAuth()
  const [isAdmin, setIsAdmin] = useState(false)
  const [adminUser, setAdminUser] = useState<AdminUser | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    checkAdminStatus()
  }, [user])

  const checkAdminStatus = async () => {
    if (!user) {
      setIsAdmin(false)
      setAdminUser(null)
      setLoading(false)
      return
    }

    try {
      // Verificar en la tabla usuario si existe y tiene rol admin
      const { data: userData, error } = await supabase
        .from('usuario')
        .select('*')
        .eq('email', user.email)
        .single()

      if (error) {
        console.log('Usuario no encontrado en tabla usuario, creando entrada...')
        // Si no existe, crear una entrada por defecto
        const { data: newUser, error: createError } = await supabase
          .from('usuario')
          .insert({
            nombre: user.email?.split('@')[0] || 'Usuario',
            email: user.email,
            nivel: 1,
            rol: 'usuario' // Por defecto usuario normal
          })
          .select()
          .single()

        if (!createError && newUser) {
          setIsAdmin(false)
          setAdminUser({
            id: user.id,
            email: user.email || '',
            isAdmin: false,
            role: 'usuario'
          })
        }
      } else {
        // Usuario encontrado, verificar rol
        const userIsAdmin = userData.rol === 'admin'
        setIsAdmin(userIsAdmin)
        setAdminUser({
          id: user.id,
          email: user.email || '',
          isAdmin: userIsAdmin,
          role: userData.rol,
          metadata: userData
        })
      }
    } catch (error: any) {
      console.error('Error verificando status de admin:', error)
      setIsAdmin(false)
      setAdminUser(null)
    } finally {
      setLoading(false)
    }
  }

  const promoteToAdmin = async (userEmail: string) => {
    if (!isAdmin) throw new Error('No tienes permisos de administrador')
    
    const { error } = await supabase
      .from('usuario')
      .update({ rol: 'admin' })
      .eq('email', userEmail)
    
    if (error) throw error
    return true
  }

  const revokeAdmin = async (userEmail: string) => {
    if (!isAdmin) throw new Error('No tienes permisos de administrador')
    
    const { error } = await supabase
      .from('usuario')
      .update({ rol: 'usuario' })
      .eq('email', userEmail)
    
    if (error) throw error
    return true
  }

  return {
    isAdmin,
    adminUser,
    loading,
    checkAdminStatus,
    promoteToAdmin,
    revokeAdmin
  }
}

export default useAdmin