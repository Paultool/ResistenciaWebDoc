import { createClient } from '@supabase/supabase-js'

// URL y clave pública de Supabase
const supabaseUrl = 'https://atogaijnlssrgkvilsyp.supabase.co'
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImF0b2dhaWpubHNzcmdrdmlsc3lwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTY4NTU3NDQsImV4cCI6MjA3MjQzMTc0NH0.4wwaY-aOZMMHstVkSh3uh3awRhv14pPJW9Xv6jGDZ98'

// Crear y exportar el cliente de Supabase
export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Función helper para verificar la conexión
export const testConnection = async (): Promise<boolean> => {
  try {
    const { data, error } = await supabase.from('historia').select('count')
    if (error) throw error
    console.log('✅ Conexión a Supabase exitosa')
    return true
  } catch (error: any) {
    console.error('❌ Error conectando a Supabase:', error.message)
    return false
  }
}

// Definir tipos para las entidades basado en la estructura real
export interface Historia {
  id_historia: number
  titulo: string
  narrativa: string
  estado: string
  orden: number
  id_ubicacion: number
  // Campos mapeados para compatibilidad
  id: number
  descripcion: string
  fecha_creacion: string
  nivel_acceso_requerido: number
  es_historia_principal: boolean
  metadata: any
}

export interface Personaje {
  id_personaje: number
  nombre: string
  descripcion: string
  imagen: string
  atributos_json: string
  // Campos mapeados
  id: number
  rol: string
  metadata: any
}

export interface Ubicacion {
  id_ubicacion: number
  nombre: string
  descripcion: string
  latitud: number
  longitud: number
  // Campos mapeados
  id: number
  metadata: any
}

// Función para obtener todas las historias
export const obtenerHistorias = async (): Promise<Historia[]> => {
  try {
    const { data: historiasRaw, error } = await supabase
      .from('historia')
      .select('*')
      .order('orden', { ascending: true })
    
    if (error) throw error
    
    // Mapear datos a la estructura esperada
    const historias: Historia[] = (historiasRaw || []).map((h: any) => ({
      ...h,
      id: h.id_historia,
      descripcion: h.narrativa,
      fecha_creacion: '2024-01-01', // Fecha simulada
      nivel_acceso_requerido: h.orden <= 2 ? 1 : 2, // Simular niveles
      es_historia_principal: h.orden <= 2, // Primeras 2 son principales
      metadata: { estado: h.estado, ubicacion_id: h.id_ubicacion }
    }))
    
    return historias
  } catch (error: any) {
    console.error('Error obteniendo historias:', error.message)
    throw error
  }
}

// Función para obtener una historia específica con detalles
export const obtenerHistoriaDetalle = async (id: number): Promise<any> => {
  try {
    const { data: historiaRaw, error } = await supabase
      .from('historia')
      .select('*')
      .eq('id_historia', id)
      .single()
    
    if (error) throw error
    
    // Obtener recursos relacionados (simulados por ahora)
    const personajes = await obtenerPersonajes()
    const ubicacion = await obtenerUbicacionPorId(historiaRaw.id_ubicacion)
    
    // Mapear a estructura esperada
    const historia = {
      ...historiaRaw,
      id: historiaRaw.id_historia,
      descripcion: historiaRaw.narrativa,
      fecha_creacion: '2024-01-01',
      nivel_acceso_requerido: historiaRaw.orden <= 2 ? 1 : 2,
      es_historia_principal: historiaRaw.orden <= 2,
      metadata: { estado: historiaRaw.estado, ubicacion_id: historiaRaw.id_ubicacion },
      // Relaciones simuladas
      personaje: personajes.slice(0, 2), // Tomar algunos personajes
      recursomultimedia: [], // Vacío por ahora
      ubicacion: ubicacion ? [ubicacion] : []
    }
    
    return historia
  } catch (error: any) {
    console.error('Error obteniendo historia detalle:', error.message)
    throw error
  }
}

// Función para obtener personajes
export const obtenerPersonajes = async (): Promise<Personaje[]> => {
  try {
    const { data: personajesRaw, error } = await supabase
      .from('personaje')
      .select('*')
      .order('nombre', { ascending: true })
    
    if (error) throw error
    
    // Mapear a estructura esperada
    const personajes: Personaje[] = (personajesRaw || []).map((p: any) => {
      let atributos: any = {}
      try {
        atributos = JSON.parse(p.atributos_json || '{}')
      } catch (e) {
        atributos = {}
      }
      
      return {
        ...p,
        id: p.id_personaje,
        rol: (atributos as any).profesion || 'Personaje',
        metadata: atributos
      }
    })
    
    return personajes
  } catch (error: any) {
    console.error('Error obteniendo personajes:', error.message)
    throw error
  }
}

// Función para obtener ubicaciones
export const obtenerUbicaciones = async (): Promise<Ubicacion[]> => {
  try {
    const { data: ubicacionesRaw, error } = await supabase
      .from('ubicacion')
      .select('*')
      .order('nombre', { ascending: true })
    
    if (error) throw error
    
    // Mapear a estructura esperada
    const ubicaciones: Ubicacion[] = (ubicacionesRaw || []).map((u: any) => {
      const [lat, lng] = (u.coordenadas || '0,0').split(',').map(parseFloat)
      return {
        ...u,
        id: u.id_ubicacion,
        latitud: lat || 0,
        longitud: lng || 0,
        metadata: { tipo: u.tipo }
      }
    })
    
    return ubicaciones
  } catch (error: any) {
    console.error('Error obteniendo ubicaciones:', error.message)
    throw error
  }
}

// Función helper para obtener una ubicación por ID
export const obtenerUbicacionPorId = async (id: number): Promise<Ubicacion | null> => {
  try {
    const { data: ubicacionRaw, error } = await supabase
      .from('ubicacion')
      .select('*')
      .eq('id_ubicacion', id)
      .single()
    
    if (error) return null
    
    const [lat, lng] = (ubicacionRaw.coordenadas || '0,0').split(',').map(parseFloat)
    return {
      ...ubicacionRaw,
      id: ubicacionRaw.id_ubicacion,
      latitud: lat || 0,
      longitud: lng || 0,
      metadata: { tipo: ubicacionRaw.tipo }
    }
  } catch (error: any) {
    console.error('Error obteniendo ubicación:', error.message)
    return null
  }
}